/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>

void findWaitingTime(int processes[], int n, float bt[], float wt[])
{
    wt[0] = 0;
    for (int i = 1; i < n; i++)
        wt[i] = bt[i - 1] + wt[i - 1];
}

void findTurnAroundTime(int processes[], int n, float bt[], float wt[], float tat[])
{
    for (int i = 0; i < n; i++)
        tat[i] = bt[i] + wt[i];
}

void findAverageTime(int processes[], int n, float bt[])
{
    float wt[n], tat[n], total_wt = 0, total_tat = 0;
   
    findWaitingTime(processes, n, bt, wt);
    findTurnAroundTime(processes, n, bt, wt, tat);
   
    printf("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time\n");
   
    for (int i = 0; i < n; i++) {
        total_wt += wt[i];
        total_tat += tat[i];
        printf("%d\t%.2f\t\t%.2f\t\t%.2f\n", i + 1, bt[i], wt[i], tat[i]);
    }
   
    printf("\nAverage waiting time: %.2f", total_wt / n);
    printf("\nAverage turnaround time: %.2f", total_tat / n);
}

int main()
{
    int n;
    printf("Enter the number of processes: ");
    scanf("%d", &n);
   
    int processes[n];
    float burst_time[n];
   
    printf("\nEnter burst time for each process:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d: ", i + 1);
        scanf("%f", &burst_time[i]);
        processes[i] = i + 1;
    }
   
    findAverageTime(processes, n, burst_time);
   
    return 0;
}



